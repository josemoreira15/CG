#ifndef __TRANSFORMATION_HPP__
#define __TRANSFORMATION_HPP__

class Transformation{
    public:
        virtual void apply_transformation(){};
};

#endif